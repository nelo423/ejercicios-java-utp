package model.vo;

public class SumaProveedor {

    

}
