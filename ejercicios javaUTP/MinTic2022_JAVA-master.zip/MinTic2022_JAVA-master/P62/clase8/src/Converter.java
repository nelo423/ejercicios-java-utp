public class Converter {

    private String document;

    public Converter(String document) {
        this.document = document;
    }

    public String getDocument() {
        return document;
    }

    public String makeLine(){
        return "";
    }

    public String makeParagraph(){
        return "";
    }
    
    public String makeTable(){
        return "";
    }


}